package com.example.jogomemoria

data class Memoria(val id: Int, var virada: Boolean = false, var igual: Boolean = false )